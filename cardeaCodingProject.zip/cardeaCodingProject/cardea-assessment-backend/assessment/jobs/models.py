from django.db import models


class List(models.Model):
    name = models.CharField(max_length=200)
    description = models.TextField()
    image = models.URLField()


class Job(models.Model):
    id = models.IntegerField(primary_key=True)
    job_title = models.CharField(max_length=200)
    company = models.CharField(max_length=200)
    location = models.CharField(max_length=200)
    min_salary = models.IntegerField()
    max_salary = models.IntegerField()
    apply_link = models.URLField()


class List_For_Job(models.Model):
    list_name = models.CharField(max_length=200)
    job = models.ForeignKey(Job, on_delete=models.CASCADE)
