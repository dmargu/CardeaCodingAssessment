from django.contrib import admin
from .models import Job, List, List_For_Job
# Register your models here.

admin.site.register(Job)
admin.site.register(List)
admin.site.register(List_For_Job)
