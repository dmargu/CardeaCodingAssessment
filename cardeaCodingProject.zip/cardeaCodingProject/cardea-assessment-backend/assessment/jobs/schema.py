import graphene
from graphene_django import DjangoObjectType
from .models import Job, List, List_For_Job


class JobType(DjangoObjectType):
    class Meta:
        model = Job
        fields = ("id", "job_title", "company", "location", "min_salary", "max_salary", "apply_link")


class ListType(DjangoObjectType):
    class Meta:
        model = List
        fields = ("name", "description", "image")


class List_For_JobType(DjangoObjectType):
    class Meta:
        model = List_For_Job
        fields = ("list_name", "job")


class Query(graphene.ObjectType):
    all_jobs = graphene.List(JobType)
    all_lists = graphene.List(ListType)
    all_job_lists = graphene.List(List_For_JobType)

    def resolve_all_jobs(root, info):
        return Job.objects.all()

    def resolve_all_lists(root, info):
        return List.objects.all()

    def resolve_all_job_lists(root, info):
        return List_For_Job.objects.all()


schema = graphene.Schema(query=Query)
