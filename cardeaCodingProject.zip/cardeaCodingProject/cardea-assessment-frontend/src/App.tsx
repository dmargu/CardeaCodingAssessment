import React, { useReducer } from 'react'
import CSS from 'csstype'
import ListsHeader from './components/lists/ListsHeader'
import JobFeed from './components/jobs/JobFeed'

function App() {
  const initialState = {
    cardeaFavsActive: true,
    bigTechActive: true,
    workFromHomeActive: true,
    futureOfFoodActive: true
  }

  const reducer = (state: any, action: any) => { //simpler to pass down reducer state than
    switch (action.type) {                       //different function handlers
      case 'changeCardeaFavs':
        return {...state, cardeaFavsActive: !state.cardeaFavsActive}
      case 'changebigTech':
        return {...state, bigTechActive: !state.bigTechActive}
      case 'changeWorkFromHome':
        return {...state, workFromHomeActive: !state.workFromHomeActive}
      case 'changeFutureOfFood':
        return {...state, futureOfFoodActive: !state.futureOfFoodActive}
    }
  }

  const [state, dispatch] = useReducer(reducer, initialState)
  return (
    <div className="App">
      <div style={headerStyle}>
        <div style={headerTextStyle}>
          <h2 style={cardeaStyle}>cardea</h2>
          <h3 style={textStyle}>Show Me Jobs From...</h3>
        </div>
        <ListsHeader state={state} dispatch={dispatch}/>
      </div>
      <div style={listContainerStyle}>
        <JobFeed state={state}/>
      </div>
    </div>
  );
}

const headerStyle: CSS.Properties = {
  display: 'flex',
  flexDirection: 'row'
}

const cardeaStyle: CSS.Properties = {
  color: 'rgb(252, 84, 96)',
  paddingRight: '80px'
}

const listContainerStyle: CSS.Properties = {
  scrollBehavior: 'smooth',
  height: '75%',
  width: '100%',
  overflow: 'auto',
  position: 'fixed',
  display: 'flex',
  justifyContent: 'center',
  marginTop: '150px'
}

const textStyle: CSS.Properties = {
  paddingTop: '5px'
}

const headerTextStyle: CSS.Properties = {
  display: 'flex',
  flexDirection: 'row',
  justifyContent: 'space-around',
  position: 'relative',
  width: '25%'
}

export default App;
