import React from 'react'
import CSS from 'csstype'
import { useQuery } from "@apollo/react-hooks"
import { LOAD_LISTS } from '../../GraphQL/queries'
import ListCard from './ListCard'

interface props {
  state: {
    cardeaFavsActive: boolean,
    bigTechActive: boolean,
    workFromHomeActive: boolean,
    futureOfFoodActive: boolean
  },
  dispatch: any
}

const ListHeader = (props: props) => {
  const { loading, error, data } = useQuery(LOAD_LISTS)
  return (
    <div style={containerStyle}>
      {loading && <div/>}
      {error && <h1 style={errorStyle}>Error Loading Lists</h1>}
      {data &&
        <div style={listContainerStyle}>
          <ListCard
            label={data.allLists[0].name}
            imgSrc={data.allLists[0].image}
            description={data.allLists[0].description}
            state={props.state.cardeaFavsActive}
            dispatch={props.dispatch}
            dispatchType={'changeCardeaFavs'}
          />
          <ListCard
            label={data.allLists[1].name}
            imgSrc={data.allLists[1].image}
            description={data.allLists[1].description}
            state={props.state.bigTechActive}
            dispatch={props.dispatch}
            dispatchType={'changebigTech'}
          />
          <ListCard
            label={data.allLists[2].name}
            imgSrc={data.allLists[2].image}
            description={data.allLists[2].description}
            state={props.state.workFromHomeActive}
            dispatch={props.dispatch}
            dispatchType={'changeWorkFromHome'}
          />
          <ListCard
            label={data.allLists[3].name}
            imgSrc={data.allLists[3].image}
            description={data.allLists[3].description}
            state={props.state.futureOfFoodActive}
            dispatch={props.dispatch}
            dispatchType={'changeFutureOfFood'}
          />
        </div>
      }
    </div>
  )
}

const containerStyle: CSS.Properties = {
  display: 'flex',
  flexDirection: 'row',
}

const listContainerStyle: CSS.Properties = {
  display: 'flex',
  justifyContent: 'center',
  right: '-10px',
  width: '100%',
  position: 'fixed'
}

const errorStyle: CSS.Properties = {
  display: 'flex',
  justifyContent: 'center',
  width: '50%',
  position: 'fixed'
}

export default ListHeader
