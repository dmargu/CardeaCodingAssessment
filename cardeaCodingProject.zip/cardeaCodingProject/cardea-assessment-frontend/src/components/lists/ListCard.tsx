import React, {useState} from 'react'
import { withStyles } from '@material-ui/core/styles'
import Tooltip from '@material-ui/core/Tooltip'
import Fade from "@material-ui/core/Fade";
import CSS from 'csstype'

interface props {
  label: string,
  imgSrc: string,
  description: string,
  state: boolean,
  dispatch: any,
  dispatchType: string
}

const CustomTooltip = withStyles({
  tooltip: {
    fontSize: '16px',
    backgroundColor: 'rgb(252, 84, 96)'
  }
})(Tooltip)

const ListCard = (props: props) => {
  const [isHovering, changeHover] = useState(false)
  return (
    <div //show cursor pointer if the user is hovering over the list
      style={isHovering ? {...containerStyle, ...cursorStyle}: containerStyle}
      onMouseOver={() => changeHover(true)}
      onMouseOut={() => changeHover(false)}
      onClick={() => props.dispatch({ type: props.dispatchType })}
    >
      <CustomTooltip //show tooltip description when user hovers
        title={props.description}
        TransitionComponent={Fade}
        TransitionProps={{ timeout: 500 }}
      >
        <div>
          <h3 style={props.state ? labelStyleStateTrue:labelStyle}>{props.label}</h3>
          <div style={imageContainerStyle}>
            <img
              src={props.imgSrc}
              alt={'List logo'} 
              height={150}
              width={150}
              style={imgStyle}
            />
          </div>
        </div>
      </CustomTooltip>
    </div>
  )
}

const containerStyle: CSS.Properties = {
  paddingLeft: '25px',
  paddingTop: '5px',
  paddingRight: '25px'
}

const labelStyle: CSS.Properties = {
  textAlign: 'center'
}

const labelStyleStateTrue: CSS.Properties = {
  textAlign: 'center',
  color: 'rgb(252, 84, 96)'
}

const imgStyle: CSS.Properties = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  boxShadow: '1px 1px 6px 3px #ccc'
}

const imageContainerStyle: CSS.Properties = {
  paddingLeft: '7px'
}

const cursorStyle: CSS.Properties = {
  cursor: 'pointer'
}

export default ListCard
