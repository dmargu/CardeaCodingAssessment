import React from 'react';
import CSS from 'csstype'
import { useQuery } from "@apollo/react-hooks"
import { LOAD_JOBS_AND_JOB_LISTS } from '../../GraphQL/queries'
import JobCard from './JobCard'

interface props {
  state: {
    cardeaFavsActive: boolean,
    bigTechActive: boolean,
    workFromHomeActive: boolean,
    futureOfFoodActive: boolean
  }
}

const getActiveState = (state: any) => { //get array of active lists to show jobs for
  const activeList: any = []
  if (state.cardeaFavsActive) {
    activeList.push('Cardea\'s Favorites')
  }
  if (state.bigTechActive) {
    activeList.push('Big Tech')
  }
  if (state.workFromHomeActive) {
    activeList.push('Work From Home')
  }
  if (state.futureOfFoodActive) {
    activeList.push('Future Of Food')
  }
  return activeList
}

const JobFeed = (props: props) => {
  const { loading, error, data } = useQuery(LOAD_JOBS_AND_JOB_LISTS)
  const jobList: { id: number, jobTitle: string, company: string, location: string, minSalary: number,
                   maxSalary: number, applyLink: string, lists: string[] }[]  = []
  if (data) {
    for (let x = 0; x < data.allJobs.length; x++) {
      const job = data.allJobs[x]
      const listsForJob = []
      for (let i = 0; i < data.allJobLists.length; i++) {
        const listItem = data.allJobLists[i]
        if (listItem.job.id === job.id) { //if a job and list item share an id push the name of the
          listsForJob.push(listItem.listName) //list item to the jobs lists
        }
      }
      job.lists = listsForJob
      jobList.push(job)
    }
  }
  const activeList = getActiveState(props.state)
  const activeJobs = jobList.filter(job => { //only show jobs that are included in an active list
    for (let x=0; x < job.lists.length; x++) {
      if (activeList.includes(job.lists[x])) {
        return true
      }
    }
    return false
  })
  return (
    <div>
      {loading && <div/>}
      {error && <h1>Error Loading Jobs</h1>}
      {data &&
        <ul>
          {activeJobs.map(item => {
            return (
              <li key={item.id} style={listStyle}>
                <JobCard item={item}/>
              </li>)
          })}
        </ul>
      }
    </div>
  )
}

const listStyle: CSS.Properties = {
  display: 'flex',
  flexDirection: 'column',
  listStyleType: 'none',
  listStyle: 'none',
}

export default JobFeed
