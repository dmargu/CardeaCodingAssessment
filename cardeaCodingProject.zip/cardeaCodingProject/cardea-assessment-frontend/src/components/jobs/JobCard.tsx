import React, { useState } from 'react'
import { FaLocationArrow } from 'react-icons/fa'
import { GiMoneyStack } from "react-icons/gi";
import CSS from 'csstype'


interface props {
  item: {
    id: number,
    jobTitle: string,
    company: string,
    location: string,
    minSalary: number,
    maxSalary: number,
    applyLink: string,
    lists: string[],
  }
}

function numWithComma(x: number) { //adds comma to number
    return x.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",");
}

const JobCard = (props: props) => {
  const [showApplyLink, changeLinkVisability] = useState(false)
  const [isHovering, changeHover] = useState(false)
  const [isHoveringApplyLink, changeHoverApplyLink] = useState(false)
  return (
    <div //make cursor pointer if hovering over card
      style={isHovering ? {...containerStyle, ...cursorStyle}: containerStyle}
      onClick={() => changeLinkVisability(!showApplyLink)}
      onMouseOver={() => changeHover(true)}
      onMouseOut={() => changeHover(false)}
    >
      <h3>{props.item.company}</h3>
      <h2>{props.item.jobTitle}</h2>
      <div style={subinfoStyle}>
        <div style={subinfoStyle}>
          <FaLocationArrow size='20px' color='rgb(252, 84, 96)'/>
          <h4 style={subTextStyle}>{props.item.location}</h4>
        </div>
        <div style={salaryStyle}>
          <GiMoneyStack size='25px' color='green'/>
          <h4 style={subTextStyle}>
            ${numWithComma(props.item.minSalary)}-{numWithComma(props.item.maxSalary)}
          </h4>
        </div>
      </div>
      {showApplyLink &&
        <div onClick={() => { //open application link in new tab
          window.open(props.item.applyLink, '_blank')
          changeHoverApplyLink(false)
        }}>
          <h4
            style={isHoveringApplyLink ? hoveringApplyStyle: applyTextStyle}
            onMouseOver={() => changeHoverApplyLink(true)}
            onMouseOut={() => changeHoverApplyLink(false)}
          >
            Click here to apply!
          </h4>
        </div>
      }
    </div>
  )
}

const containerStyle: CSS.Properties = {
  border: '1px solid #ccc',
  width: '700px',
  padding: '10px',
  paddingBottom: '0px',
  borderRadius: '8px',
  margin: '10px',
  boxShadow: '1px 1px 6px 3px #ccc',
}

const cursorStyle: CSS.Properties = {
  cursor: 'pointer'
}

const subinfoStyle: CSS.Properties = {
  display: 'flex',
  flexDirection: 'row'
}

const salaryStyle: CSS.Properties = {
  display: 'flex',
  flexDirection: 'row',
  paddingLeft: '40px'
}

const subTextStyle: CSS.Properties = {
  paddingLeft: '20px',
  position: 'relative',
  bottom: '20px'
}

const applyTextStyle: CSS.Properties = {
  color: 'rgb(252, 84, 96)',
  top: '-10px',
  position: 'relative'
}

const hoveringApplyStyle: CSS.Properties = {
  color: 'gray',
  top: '-10px',
  position: 'relative'
}

export default JobCard
