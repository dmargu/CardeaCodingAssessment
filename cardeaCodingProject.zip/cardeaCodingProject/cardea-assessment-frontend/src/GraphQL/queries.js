import gql from "graphql-tag"

export const LOAD_JOBS_AND_JOB_LISTS = gql`
  query {
    allJobs {
      id
      jobTitle
      company
      location
      minSalary
      maxSalary
      applyLink
    }
    allJobLists {
      listName
      job {
        id
      }
    }
  }
`

export const LOAD_LISTS = gql`
  query{
    allLists {
      name
      description
      image
    }
  }
`
